﻿using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace CustomerManagementApp
{
    public partial class CustomerListForm : Window
    {
        public CustomerListForm()
        {
            InitializeComponent();
            LoadCustomerData();
        }

        private void LoadCustomerData()
        {
            string connectionString = "Data Source=customers.db;Version=3;";
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Customers";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    CustomerDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
        }

        private void ExportCustomerToTextFile_Click(object sender, RoutedEventArgs e)
        {
            string customerId = txtCustomerId.Text;

            if (string.IsNullOrWhiteSpace(customerId))
            {
                MessageBox.Show("Vui lòng nhập ID khách hàng!", "Thông Báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string connectionString = "Data Source=customers.db;Version=3;";
            string query = "SELECT * FROM Customers WHERE ID = @ID";

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", customerId);
                    using (SQLiteDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            SaveFileDialog saveFileDialog = new SaveFileDialog
                            {
                                Filter = "Text files (*.txt)|*.txt",
                                Title = "Chọn Địa Chỉ Lưu File",
                                FileName = $"{customerId}.txt"
                            };

                            if (saveFileDialog.ShowDialog() == true)
                            {
                                string filePath = saveFileDialog.FileName;

                                try
                                {
                                    using (StreamWriter writer = new StreamWriter(filePath))
                                    {
                                        // Xuất dữ liệu theo định dạng yêu cầu
                                        writer.WriteLine($"ID: {reader["ID"]}");
                                        writer.WriteLine($"Name: {reader["Name"]}");
                                        writer.WriteLine($"Phone: {reader["Phone"]}");
                                        writer.WriteLine($"Birth Year: {reader["BirthYear"]}");
                                        writer.WriteLine($"Gender: {reader["Gender"]}");
                                    }
                                    MessageBox.Show($"Dữ liệu khách hàng đã được xuất thành công vào file: {filePath}", "Thông Báo", MessageBoxButton.OK, MessageBoxImage.Information);
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show($"Lỗi khi xuất dữ liệu: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("ID khách hàng không tồn tại!", "Thông Báo", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                }
            }
        }
    }
}
