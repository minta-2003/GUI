﻿using System;
using System.Data.SQLite;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace CustomerManagementApp
{
    public partial class RegistrationForm : Window
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private async void SubmitForm_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string phone = txtPhone.Text;
            string birthYear = txtBirthYear.Text;
            string gender = (cmbGender.SelectedItem as ComboBoxItem)?.Tag.ToString();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(birthYear) || string.IsNullOrEmpty(gender))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            string newId = GenerateNewId();
            try
            {
                using (SQLiteConnection conn = new SQLiteConnection("Data Source=customers.db;Version=3;"))
                {
                    conn.Open();
                    string query = "INSERT INTO Customers (ID, Name, Phone, BirthYear, Gender) VALUES (@ID, @Name, @Phone, @BirthYear, @Gender)";
                    using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", newId);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Phone", phone);
                        cmd.Parameters.AddWithValue("@BirthYear", birthYear);
                        cmd.Parameters.AddWithValue("@Gender", gender);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show($"Đăng ký khách hàng thành công! Mã khách hàng là: {newId}");

                        // Xuất file
                        ExportToFile(newId);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Có lỗi xảy ra: " + ex.Message);
            }
        }

        private void ExportToFile(string customerId)
        {
            string directoryPath = @"D:\GUI\RS\resource";
            string filePath = Path.Combine(directoryPath, $"{customerId}.txt");

            // Nội dung file
            string fileContent = $"ID: {customerId}\nName: {txtName.Text}\nPhone: {txtPhone.Text}\nBirth Year: {txtBirthYear.Text}\nGender: {(cmbGender.SelectedItem as ComboBoxItem)?.Content}";

            // Xuất file
            File.WriteAllText(filePath, fileContent);
        }

        private string GenerateNewId()
        {
            string newId = "80001";
            using (SQLiteConnection conn = new SQLiteConnection("Data Source=customers.db;Version=3;"))
            {
                conn.Open();
                string query = "SELECT MAX(ID) FROM Customers";
                using (SQLiteCommand cmd = new SQLiteCommand(query, conn))
                {
                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value && result != null)
                    {
                        string maxId = result.ToString();
                        int idNumber = int.Parse(maxId) + 1; // Lấy số từ ID và tăng lên
                        newId = idNumber.ToString(); // Định dạng số thành ba chữ số
                    }
                }
            }
            return newId;
        }

        private void cmbGender_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
