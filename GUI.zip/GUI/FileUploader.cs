﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

public class FileUploader
{
    private static readonly string githubToken = "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";
    private static readonly string owner = "bejito555";
    private static readonly string repo = "tutorial1";
    private static readonly string branch = "main";
    private static readonly string folderPath = @"D:\GUI\RS\resource";

    private static readonly ConcurrentDictionary<string, bool> processingFiles = new ConcurrentDictionary<string, bool>();

    public FileUploader()
    {
        StartWatching();
    }

    private void StartWatching()
    {
        FileSystemWatcher watcher = new FileSystemWatcher
        {
            Path = folderPath,
            Filter = "*.txt",
            NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite
        };

        watcher.Created += OnChanged;
        watcher.Changed += OnChanged;

        watcher.EnableRaisingEvents = true;

        Console.WriteLine("Watching directory. Press [Enter] to exit.");
    }

    private async void OnChanged(object source, FileSystemEventArgs e)
    {
        if (processingFiles.ContainsKey(e.FullPath))
        {
            return;
        }

        processingFiles[e.FullPath] = true;

        try
        {
            // Wait a moment to ensure the file has finished being written
            await Task.Delay(1000);

            if (File.Exists(e.FullPath))
            {
                Console.WriteLine($"Detected change: {e.FullPath}");
                await UploadFileToGitHub(e.FullPath, "Automatically upload file");
            }
        }
        finally
        {
            processingFiles.TryRemove(e.FullPath, out _);
        }
    }

    public async Task UploadFileToGitHub(string filePath, string commitMessage)
    {
        string fileName = Path.GetFileName(filePath);
        byte[] fileBytes = File.ReadAllBytes(filePath);
        string fileContent = Convert.ToBase64String(fileBytes);

        string url = $"https://api.github.com/repos/{owner}/{repo}/contents/{fileName}";

        using (HttpClient client = new HttpClient())
        {
            client.DefaultRequestHeaders.Add("Authorization", $"token {githubToken}");
            client.DefaultRequestHeaders.Add("User-Agent", "CSharpApp");

            try
            {
                // Check if file already exists
                HttpResponseMessage getResponse = await client.GetAsync(url);
                if (getResponse.IsSuccessStatusCode)
                {
                    var existingContent = await getResponse.Content.ReadAsStringAsync();
                    var existingFile = JObject.Parse(existingContent);
                    string sha = existingFile["sha"].ToString();

                    var json = new
                    {
                        message = commitMessage,
                        content = fileContent,
                        sha = sha,
                        branch = branch
                    };

                    var jsonString = JObject.FromObject(json).ToString();
                    var content = new StringContent(jsonString, Encoding.UTF8, "application/json");

                    HttpResponseMessage putResponse = await client.PutAsync(url, content);

                    if (putResponse.IsSuccessStatusCode)
                    {
                        Console.WriteLine($"Successfully uploaded file {fileName}!");
                    }
                    else
                    {
                        string errorResponse = await putResponse.Content.ReadAsStringAsync();
                        Console.WriteLine($"Error uploading file {fileName}: " + errorResponse);
                    }
                }
                else
                {
                    // If file does not exist, create a new one
                    var json = new
                    {
                        message = commitMessage,
                        content = fileContent,
                        branch = branch
                    };

                    var jsonString = JObject.FromObject(json).ToString();
                    var content = new StringContent(jsonString, Encoding.UTF8, "application/json");

                    HttpResponseMessage putResponse = await client.PutAsync(url, content);

                    if (putResponse.IsSuccessStatusCode)
                    {
                        Console.WriteLine($"Successfully uploaded file {fileName}!");
                    }
                    else
                    {
                        string errorResponse = await putResponse.Content.ReadAsStringAsync();
                        Console.WriteLine($"Error uploading file {fileName}: " + errorResponse);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing file {fileName}: {ex.Message}");
            }
        }
    }
}
