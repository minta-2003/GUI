﻿using System;
using System.Data.SQLite;
using System.IO;
using System.Windows;

namespace CustomerManagementApp
{
    public partial class AddOrderWindow : Window
    {
        public AddOrderWindow()
        {
            InitializeComponent();
        }

        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            string customerId = txtCustomerId.Text;
            string productCode = txtProductCode.Text;
            if (!double.TryParse(txtWeight.Text, out double weight))
            {
                MessageBox.Show("Số Kg không hợp lệ!");
                return;
            }

            // Generate Order ID
            string orderId = GenerateOrderId(customerId);

            // Retrieve customer name
            string customerName = GetCustomerName(customerId);

            if (customerName == null)
            {
                MessageBox.Show("ID khách hàng không tồn tại!");
                return;
            }

            // Save order to database
            SaveOrder(orderId, customerId, productCode, weight);

            // Export order details to file
            ExportOrderToFile(orderId, customerId, productCode, weight);

            // Display order details
            MessageBox.Show($"Đơn hàng đã được tạo:\nMã Đơn Hàng: {orderId}\nThời Gian Tạo: {DateTime.Now}\nTên Khách Hàng: {customerName}\nSố Kg: {weight}");
        }

        private string GenerateOrderId(string customerId)
        {
            string connectionString = "Data Source=customers.db;Version=3;";
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                // Modified query to extract the numeric part of the OrderID based on underscore position
                string query = @"
        SELECT MAX(CAST(SUBSTR(OrderID, 1, INSTR(OrderID, '_') - 1) AS INTEGER)) 
        FROM Orders 
        WHERE OrderID LIKE '%' || @CustomerID || '%'";

                using (var command = new SQLiteCommand(query, connection))
                {
                    // Add the customerId as a parameter to prevent SQL injection
                    command.Parameters.AddWithValue("@CustomerID", customerId);
                    var result = command.ExecuteScalar();

                    int nextOrderNumber = 1000; // Start order numbers from 1000 by default
                    if (result != DBNull.Value && result != null)
                    {
                        if (int.TryParse(result.ToString(), out int orderNumber))
                        {
                            nextOrderNumber = orderNumber + 1;
                        }
                    }

                    // Return the OrderID in the format 'OrderNumber_CustomerID'
                    return $"{nextOrderNumber}_{customerId}";
                }
            }
        }






        private string GetCustomerName(string customerId)
        {
            string connectionString = "Data Source=customers.db;Version=3;";
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Name FROM Customers WHERE ID = @ID";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", customerId);
                    var result = command.ExecuteScalar();
                    return result?.ToString();
                }
            }
        }

        private void SaveOrder(string orderId, string customerId, string productCode, double weight)
        {
            string connectionString = "Data Source=customers.db;Version=3;";
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = @"
                    CREATE TABLE IF NOT EXISTS Orders (
                        OrderID TEXT PRIMARY KEY,
                        CustomerID TEXT NOT NULL,
                        ProductCode TEXT NOT NULL,
                        Weight REAL NOT NULL,
                        OrderDate TEXT NOT NULL
                    );";

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }

                query = "INSERT INTO Orders (OrderID, CustomerID, ProductCode, Weight, OrderDate) VALUES (@OrderID, @CustomerID, @ProductCode, @Weight, @OrderDate)";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrderID", orderId);
                    command.Parameters.AddWithValue("@CustomerID", customerId);
                    command.Parameters.AddWithValue("@ProductCode", productCode);
                    command.Parameters.AddWithValue("@Weight", weight);
                    command.Parameters.AddWithValue("@OrderDate", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                    command.ExecuteNonQuery();
                }
            }
        }

        private void ExportOrderToFile(string orderId, string customerId, string productCode, double weight)
        {
            string filePath = $@"D:\GUI\RS\resource\{orderId}.txt";
            string orderDetails = $"Order ID: {orderId}\nCustomer ID: {customerId}\nProduct Code: {productCode}\nWeight: {weight}\nDate: {DateTime.Now}";

            try
            {
                File.WriteAllText(filePath, orderDetails);
                MessageBox.Show($"File '{orderId}.txt' has been created successfully at {filePath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating file: {ex.Message}");
            }
        }
    }
}
